<?php
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION["username"])){
    header("Location: index.php");
}
if(!isset($_POST["loansubmit"])){
    header("Location: saving.php");
}
if(isset($_GET["doLogout"]) && $_GET["doLogout"]==True){
    unset($_SESSION["username"]);
    header("Location: index.php");
}
include("connection.php");
$sqluser="select * from member where memNationalID='$_SESSION[username]'";
$queryuser=mysqli_query($conn,$sqluser);
$result=mysqli_fetch_array($queryuser);
$mID=$result['memID'];
$sqlSum="select sum(sAmount) as totalmoney from saving where memID=$mID";
$querySum=mysqli_query($conn,$sqlSum);
$total=mysqli_fetch_array($querySum);
$sqlsave="select * from saving where memID=$mID";
$savequery=mysqli_query($conn,$sqlsave);
$saverow=mysqli_num_rows($savequery);
$sqlmember="select * from member where memID!=$mID;";
$querymember=mysqli_query($conn,$sqlmember);
if(isset($_POST["loansubmit"])){
$capital=$total["totalmoney"];
$amount=$_POST["Lamount"];
$send=$_POST["Lsend"];
$guarantor1=$_POST["Lg1"];
$guarantor2=$_POST["Lg2"];
$guarantor3=$_POST["Lg3"];
$sqlLoanForm = "INSERT INTO loan (Lcapital,Lamount,Lsend,Lguarantor1,Lguarantor2,Lguarantor3,memID) VALUES ('$capital', '$amount','$send', 
'$guarantor1', '$guarantor2', '$guarantor3', '$mID')";
$queryLoan=mysqli_query($conn,$sqlLoanForm);
}
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/jquery.min.js"></script>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
<script src="bootstrap/js/jquery.unduplicated.js"></script>
<title>หน้าแรก</title>
<style>
body {
    background-color: #5d5858;
    overflow-x: hidden;
    font-family: 'Kanit', sans-serif;
}

a {
    color: #0060B6;
    text-decoration: none;
}

a:hover {
    color: #00A0C6;
    text-decoration: none;
    cursor: pointer;
}
</style>

</head>
<body>
    <?php include("header.html");?>
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <div class="card" style="margin:10px">
                <div class="card-header bg-primary text-white" style="text-align: center;">
                    <label style="font-size: 20px; margin-top:5px">ฟอร์มเงินกู้</label>
                </div>
                <div class="card-body">
                    <span style="font-size: 30px;">เงินต้นทั้งหมด : <?php echo $total["totalmoney"];?> บาท</span>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-group" style="font-size: 18px;">
                            <label>ยอดที่ต้องการกู้</label>
                            <input name="Lamount" required class="form-control" type="text" placeholder="จำนวนเงิน" max="<?php echo $a;?>">
                        </div>
                        <div class="form-group" style="font-size: 18px;">
                            <label>จำนวนเงินที่ต้องการส่งต่อเดือน</label>
                            <input name="Lsend" required class="form-control" type="text" placeholder="จำนวนเงิน">
                            <span>(รวมดอกเบี้ย)</span>
                        </div>
                        <div class="form-group" style="font-size: 18px;">
                            <label>ผู้ค้ำประกัน</label>
                            <select class="Lg1 form-control" name="Lg1">
                            <?php foreach($querymember as $data) {?>
                                <option  value="<?php echo $data['memID'];?>"><?php echo $data["memName"]."  ".$data["memLastname"] ;?></option>
                            <?php }?>
                            </select>
                        </div>
                        <div class="form-group" style="font-size: 18px;">
                            <select class="Lg2 form-control" name="Lg2">
                                
                            <?php foreach($querymember as $data) {?>
                                <option value="<?php echo $data['memID'];?>"><?php echo $data["memName"]."  ".$data["memLastname"] ;?></option>
                            <?php }?>
                            </select>
                        </div>
                        <div class="form-group" style="font-size: 18px;">
                            <select class="Lg3 form-control" name="Lg3">
                            <?php foreach($querymember as $data) {?>
                                <option value="<?php echo $data['memID'];?>"><?php echo $data["memName"]."  ".$data["memLastname"] ;?></option>
                            <?php }?>
                            </select>
                        </div>
                        <div class="form-group" style="text-align:center">
                            <button class="btn btn btn-success" type="submit" id="loansubmit" name="loansubmit"
                                style="font-size: 16px;">ส่งข้อมูล</button>
                        </div>
                    </form>

                </div>
            </div>
            <div class="col-sm-3">
            </div>
        </div>
    </div>
    </div>
    
</body>
<script>
    $(function(){
     $(".Lg1").unduplicated(); 
 });
 $(function(){
     $(".Lg2").unduplicated(); 
 });
 $(function(){
     $(".Lg3").unduplicated(); 
 });
</script>
</html>
<?php
if($saverow<6){
    echo '
                <script>
                    swal.fire({
                        icon:"error",
                        title:"เกิดข้อผิดพลาด",
                        text:"ต้องมียอดออมทรัพท์มากกว่า 6 เดือน",
                        type:"error",
                          
                    }).then(function() {
                        window.location = "saving.php";
                    });
                </script>
                ';
}
?>