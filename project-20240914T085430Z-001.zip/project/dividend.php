<?php
include("conn.php");
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);

$sqlyear = "select * from yeardata where Ystatus = 'N'";
$queryyear = mysqli_query($conn,$sqlyear);
$year = mysqli_fetch_array($queryyear);

$sqlSum="SELECT memID, SUM(sAmount) AS totalmoney FROM saving GROUP BY memID";
$querySum=mysqli_query($conn,$sqlSum);  
foreach ($querySum as $data){
    echo $data['memID'];
    echo '<br/>';
   $panpon=$data['totalmoney']*($year['interestSaving']/100);
   echo $panpon;
   echo '<br/>';
}
if(isset($_POST['success'])){
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title><?php echo $_SESSION["titlebar"] ?></title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>
</head>
<body>
    <?php include("navbarmenu.html")?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card" style="margin-top:3%">
                    <div class="card-header bg-primary">
                        <label for="">ระบบปันผล</label>
                    </div>
                    <form action="" method="post">
                    <div class="card-body">
                        <div>
                            <label for="">วันที่</label>
                            <input type="date" name="" id="" class="form-control form-group" value="<?php echo date("Y-m-d")?>">
                        </div>
                        <div>
                            <label for="">ปี</label>
                            <input type="text" name="" id="" class="form-control form-group" value="<?php echo $year['years']?>">
                        </div>
                        <div>
                            <label for="">เปอร์เซ็นปันผล</label>
                            <input type="text" name="" id="" class="form-control form-group">
                        </div>
                        <div>
                            <label for=""></label>
                            <input type="text" name="" id="" class="form-control form-group">
                        </div>
                    </div>
                    <div class="card-footer bg-primary">
                        <button class="btn btn-success" name="success">ทำรายการ</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>
</html>