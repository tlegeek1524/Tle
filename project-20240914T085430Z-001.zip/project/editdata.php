<?php 
include("conn.php");

$id = isset($_GET['id']) ? $_GET['id']:'';
if($id!=''){

    $sql = "SELECT * from member where memID =' ".$id."'";
    $result = $conn ->query($sql);
    $row = $result->fetch_assoc();
}
if(isset($_POST['next'])){
    $name = $_POST['name'];
    $lastname = $_POST['lastname'];
    $idname = $_POST['national'];
    $phone = $_POST['numphone'];
    $sqlupdate = "UPDATE member set  memName='$name', memLastname='$lastname', memNationalID='$idname', memPhone='$phone' where memID = '$id'";
    $queryupdate = mysqli_query($conn,$sqlupdate);

    header("location:home.php");
}
if(isset($_POST['cancel'])){
    header("location: home.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<style>
        body{
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-primary">
        <img src="../assets/image/3.png" style="width: 50px;">
        <span class="" style="color: white; font-size:20px; margin:10px">ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</span>
        <ul class="navbar-nav ml-auto" style="margin-right: 20px; ">
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div class="card" style="margin-top: 3%">
                    <div class="card-header bg-primary">
                        <label for="" style="color:white;font-size:20px">เเก้ไขข้อมูลส่วนบุคคล</label>
                    </div>
                    <form action="" method="POST">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">ชื่อ-สกุล</label>
                            <input type="text" name="name" id="" class="form-control" value="<?php echo $row['memName']?>">
                            <div style="margin-top: 10px;"></div>
                            <input type="text" name="lastname" id="" class="form-control" value="<?php echo $row['memLastname']?>">
                        </div>
                        <div class="form-group">
                            <label for="">เลขบัตรประจำตัวประชาชน</label>
                            <input type="text" name="national" id="" class="form-control" value="<?php echo $row['memNationalID']?>">
                        </div>
                        <div class="form-group">
                            <label for="">เบอร์โทรศัพท์</label>
                            <input type="text" name="numphone" id="" class="form-control" value="<?php echo $row['memPhone']?>">
                        </div>
                        <div>
                            <label for="">วันเกิด</label>
                            <input type="text" name="Birthday" id="" class="form-control" value="<?php echo $row['memBirthday']?>">
                        </div>
                    </div>
                    <div class="card-footer bg-primary">
                        <div style="text-align: center;">
                        <button class="btn btn-success" name="next">บันทึกข้อมูล</button>
                        <button class="btn btn-danger" name="cancel">ยกเลิก</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
</body>
</html>