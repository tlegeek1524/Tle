<?php
include("conn.php");
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);
if (isset($_POST["back"])) {
    header("location:home.php");
}
$sqlpass = "SELECT * from member where memBirthday";
$querypass = mysqli_query($conn, $sqlpass);
$row = mysqli_fetch_array($querypass);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>ระบบออมทรัพย์วิทยาลัยเทคนิคกำแพงเพชร</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>
<?php include("navbarmenu.php")?>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div class="card" style="margin-top: 3%;">
                    <div class="card-header bg-primary" style="text-align: center;">
                        <label style="color: white;font-size:20px"><img src="../assets/image/user-icon.png" style="width: 40px;"> ระบบสมัครสมาชิก</label>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group">
                                <label>เลขบัตรประจำตัวประชาชน</label>
                                <input type="text" name="ID" id="" class="form-control" placeholder="xxxxxxxxxxxxx" maxlength="13" required="">
                            </div>
                            <div class="form-group">
                                <label for="">คำนำหน้าชื่อ</label>
                                <select name="tName" id="" class="form-control">
                                    <option value="นาย">นาย</option>
                                    <option value="นาง">นาง</option>
                                    <option value="นางสาว">นางสาว</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>ชื่อ</label>
                                <input type="text" name="username" id="" class="form-control" placeholder="ป้อนชื่อของคุณ" required="">
                            </div>
                            <div class="form-group">
                                <label>นามสกุล</label>
                                <input type="text" name="userlastname" id="" class="form-control" placeholder="ป้อนนามสกุลของคุณ" required="">
                            </div>
                            <div class="form-group">
                                <label>เพศ</label>
                                <select name="gender" id="" class="form-control">
                                    <option value="ชาย">ผู้ชาย</option>
                                    <option value="หญิง">ผู้หญิง</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>เบอร์โทรศัพท์</label>
                                <input type="tel" name="mPhone" id="" class="form-control" placeholder="xxx-xxx-xxxx" required="" maxlength="10">
                            </div>
                            <div class="form-group">
                                <label for="">จำนวณเงิน</label>
                                <input type="text" name="money" id="" class="form-control" placeholder="จำนวณเงิน" required="">
                            </div>
                    </div>
                    <div class="card-footer bg-primary" style="text-align: center;" class="form-group">
                        <button class="btn btn-success" type="submit" name="reg" style="font-size:20px">บันทึกข้อมูล</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
    <?php
    if (isset($_POST['reg'])) {
        $memid = mysqli_real_escape_string($conn, $_POST['ID']);
        $mempass = md5(1234);
        $memEmail = "-";
        $memmoney = mysqli_real_escape_string($conn, $_POST['money']);
        $memtitle = mysqli_real_escape_string($conn, $_POST['tName']);
        $memuser1 = mysqli_real_escape_string($conn, $_POST['username']);
        $memuser2 = mysqli_real_escape_string($conn, $_POST['userlastname']);
        $memphone = mysqli_real_escape_string($conn, $_POST['mPhone']);
        $memgender = mysqli_real_escape_string($conn, $_POST['gender']);
        $memadd = "-";
        $sql = "SELECT memNationalID from member where memNationalID = '$memid'";
        $query = mysqli_query($conn, $sql);
        $row =  mysqli_num_rows($query);
        if ($row > 0) {
            echo '
            <script>
            swal.fire({
                icon:"error",
                title:"เกิดข้อผิดพลาด",
                text:"เลขบัตรประชาชนนี้ถูกใช้เเล้ว",
                type:"error",
                showConfirmButton: false,
                timer:1000
                  
            });
            </script>
       ';
            } else {
                $sql = "INSERT INTO member (memNationalID,memEmail,memPassword,memAmount,memTitle,memName,memLastname,memPhone,memAddress,memGender) VALUES ('$memid','$memEmail','$mempass','$memmoney','$memtitle', '$memuser1', '$memuser2', '$memphone', '$memadd','$memgender')";
                $query = mysqli_query($conn, $sql);
                echo '
        <script>
            swal.fire({
                icon:"success",
                title:"สมัครสมาชิกเรียบร้อย",
                text:"ยินดีต้อนรับ",
                type:"success",
                showConfirmButton: false,
                timer:1000
                  
            }).then(function() {
                window.location = "home.php";
            });
        </script>
        ';
                header("location: home.php");
            }
        }
    ?>
</body>

</html>