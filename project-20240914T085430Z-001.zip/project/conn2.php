<?php
    $host ="localhost";
    $username ="root";
    $password="123456789";
    $db ="savingdb";

    #create connection
    $conn=mysqli_connect($host,$username,$password,$db);
    mysqli_set_charset($conn,"UTF8")
?>