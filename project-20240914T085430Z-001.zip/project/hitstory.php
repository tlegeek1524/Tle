<?php
include("conn.php");
session_start();

if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}

if (isset($_POST['back'])) {
    header("location: home.php");
}
$sqlhitstory = "SELECT * from member";
$queryhitstory = mysqli_query($conn, $sqlhitstory);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }

    table,
    th {
        border: 0.5px solid black;

    }

    td {
        border: 1px solid darkgray;
    }
</style>

<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
        <img src="../assets/image/3.png" style="width: 50px;">
        <span class="" style="color: white; font-size:20px; margin:10px">ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</span>
        <ul class="navbar-nav ml-auto" style="margin-right: 20px; ">
            <form action="" method="post">
                <button class="btn btn-danger" name="back" type="submit">กลับสู่หน้าหลัก</button>
            </form>
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card" style="margin-top: 5%;">
                    <div class="card-header bg-primary">

                    </div>
                    <div class="card-body">
                        <table style="width: 100%;">
                            <tr>
                                <th>ชื่อ-สกุล</th>
                                <th>ประวัติการฝาก/ถอน</th>
                                <th>วัน/เดือน/ปี</th>
                            </tr>
                            <?php foreach ($queryhitstory as $row) { ?>
                                <tr>
                                    <td><?php echo $row['memName'] . '    ' . $row['memLastname'] ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                    <div class="card-footer bg-primary">

                    </div>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>

</html>