<nav class="navbar navbar-expand-lg navbar-dark bg-primary" style="color: white;">
    <a href="home.php" class="navbar-brand">
        <img src="image/3.png" style="width: 55px;">
    </a>
    <label class="navbar-brand">ระบบออมทรัพย์วิทยาลัยเทคนิคกำแพงเพชร</label>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target = "#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNav">
        <ul class="navbar-nav ml-auto" style="margin-right:20px; font-size: 20px;">
            <li class="nav-item">
                <a href="loan.php" class="nav-link">ระบบกู้เงิน</a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">ระบบปันผล</a>
            </li>
            <li class="nav-item">
                <a href="register.php" class="nav-link">ระบบสมัครสมาชิก</a>
            </li>
            <li class="nav-item">
                <a href="saving.php" class="nav-link">ระบบออมทรัพย์</a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link"></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $result['pName'] . ' ' . $result['pLastname']; ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a href="profile.php?id=<?php echo $result['pID'] ?>" class="dropdown-item">โปรไฟล์</a>
                    <div class="dropdown-divider"></div>
                    <a href="adminreg.php" class="dropdown-item">ระบบสมัครผู้ดูเเล</a>
                    <div class="dropdown-divider"></div>
                    <a href="roundyear.php" class="dropdown-item">ระบบเพิ่มรอบ/ปี</a>
                    <div class="dropdown-divider"></div>
                    <a href="?doLogout=True" class="dropdown-item">ออกจากระบบ</a>
                </div>
    </div>
    </li>
    </ul>
    </div>
</nav>