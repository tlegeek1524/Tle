<?php
    $host ="localhost";
    $username ="root";
    $password="123456789";
    $db ="kptacth_save";

    #create connection
    $conn=mysqli_connect($host,$username,$password,$db);
    mysqli_set_charset($conn,"UTF8")
?>