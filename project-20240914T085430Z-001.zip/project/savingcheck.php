<?php 
include("conn.php");
include("../datethai.php");

$id = isset($_GET['id']) ? $_GET['id']:'';
if($id!=''){

    $sql = "SELECT * from saving where memID =' ".$id."' order by sround DESC";
    $result = $conn ->query($sql);
    $row = $result->fetch_assoc();
} 
if(isset($_POST['cancel'])){
    header("location: home.php");
}
if (isset($_POST['back'])) {
    header("location: home.php");
}
$sqlSum="select sum(sAmount) as totalmoney from saving where memID=' ".$id."'";
$querySum=mysqli_query($conn,$sqlSum);
$total=mysqli_fetch_array($querySum);

$sqlname = "SELECT * from member where memID=' ".$id."'";
$queryname1 = mysqli_query($conn,$sqlname);
$name = mysqli_fetch_array($queryname1);

if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title><?php echo $_SESSION["titlebar"]?></title>
</head>
<style>
        body{
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>
<body>
    <?php include("navbarmenu.php")?>
    <div class="container-fluid" style="margin-top:40px">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-header bg-primary" style="text-align:center">
                        <label style="font-size:20px; color:white;">ระบบออมทรัพย์</label>
                    </div>
                    <div class="card-body">
                        <div style="font-size:20px; margin-left: auto;">
                            <?php echo $name["memTitle"]."".$name["memName"]."     ".$name["memLastname"]?> <a href="savingpeople.php?id=<?php echo $name['memID'] ?>"class="btn btn-success" style="margin-left:50%;">เพิ่มออมทรัพย์</a>
                        </div>
                        <div style="font-size:20px; margin-left: auto;">
                            <?php echo "ยอดออมทั้งหมด  ".number_format($total['totalmoney'],)."   บาท"?>
                        </div>
                    <table style="width: 100%; font-size:20px; text-align:center; margin-top:10px;" class="table" id="saveinfo">
                        <thead class="bg-primary">
                            <tr style="margin-top: 20px;color:white;">
                                <th>ลำดับ</th>
                                <th>ปี</th>
                                <th>รอบ</th>
                                <th>วันที่</th>
                                <th>จำนวนเงิน</th>
                                <th>พนักงาน</th>
                            </tr>
                        </thead>
                        <tbody> <?php $i=1; ?>
                            <?php foreach($result as $data) {?>
                                
                            <tr>
                                <th><?php echo "".$i; $i++;?></th>
                                <th><?php echo $data['syear']?></th>
                                <th><?php echo $data['sround']?></th>
                                <th><?php echo datethai($data['sDate']);?></th>
                                <th><?php echo $data['sAmount']?> บาท</th>
                                <th><?php
                                $a=$data['pID'];
                                $sqlname="SELECT * from personal inner join saving on personal.pID = $a";
                                $queryname=mysqli_query($conn,$sqlname);
                                $result=mysqli_fetch_array($queryname);
                                echo $result['pName'];
                                ?></th>

                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<script>
    $(document).ready(function() {
    $('#saveinfo').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/th.json'
        }
    } );
} );
</script>
</body>
</html>