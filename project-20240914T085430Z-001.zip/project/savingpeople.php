<?php
include("conn.php");
session_start();
if (isset($_POST['back'])) {
    header("location: home.php");
}
$id = isset($_GET['id']) ? $_GET['id'] : '';
if ($id != '') {

    $sql = "SELECT * from member where memID =' " . $id . "'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    $pname = $_SESSION['username'];
    $sqlname = "SELECT * from member where memID = '$id'";
    $queryname = mysqli_query($conn, $sqlname);
    $name = mysqli_fetch_array($queryname);
    $sqlyear = "select years from yeardata where Ystatus = 'N'";
    $queryyear = mysqli_query($conn, $sqlyear);
    $year = mysqli_fetch_array($queryyear);
    $sqlshow = "SELECT rounds,rStatus from rounddata";
    $queryshow = mysqli_query($conn, $sqlshow);
    $show = mysqli_fetch_array($queryshow);
    $sqlad = "SELECT pID from personal where pUsername='$pname'";
    $queryad = mysqli_query($conn, $sqlad);
    $adname = mysqli_fetch_array($queryad);

    if (!isset($_SESSION["username"])) {
        header("Location: index.php");
    }
    if (!isset($_SESSION['password'])) {
        header("location: index.php");
    }
    if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
        unset($_SESSION["username"]);
        header("Location: index.php");
    }
    $sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
    $queryuser = mysqli_query($conn, $sqluser);
    $result = mysqli_fetch_array($queryuser);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title><?php echo $_SESSION["titlebar"] ?></title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

</head>
<body>
<?php include("navbarmenu.php")?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card" style="margin-top:3%">
                    <div class="card-header bg-primary" style="text-align:center">
                        <label style="font-size:20px; color:white;">ระบบออมทรัพย์</label>
                    </div>
                    <form action="" method="POST">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="">ชื่อ-นามสกุล</label>
                                <input readonly type="text" name="name" id="" class="form-control" value="<?php echo $name["memName"] . '   ' . $name['memLastname'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="">รอบ</label>
                                <select name="round" id="" class="form-control">
                                    <?php foreach ($queryshow as $data) { ?>
                                        <option value="<?php echo $data['rounds'] ?>">
                                            <?php
                                            if ($data['rounds'] == 0) {
                                                echo "ยอดยกมา";
                                            } else {
                                                echo $data['rounds'];
                                            } ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">ปี</label>
                                <input type="text" name="year" id="" class="form-control" value="<?php echo $year['years'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="">วันที่</label>
                                <input type="date" name="date" id="" class="form-control" value="<?php echo date("Y-m-d") ?>">
                            </div>
                            <div class="form-group">
                                <label for="">เงิน</label>
                                <input type="text" name="money" id="" class="form-control" value="<?php echo $row['memAmount'] ?>">
                            </div>
                        </div>
                        <div class="card-footer bg-primary" style="text-align: center;">
                            <button class="btn btn-success" name="success" type="submit">บันทึกข้อมูล</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>
<?php
if (isset($_POST['success'])) {
    $round1 = $_POST['round'];
    $date1 = $_POST['date'];

    $sqlchecktable = "select * from saving where sround = $round1[round] && sDate = '$date1' && memID = $id";
    $querychecktable = mysqli_query($conn, $sqlchecktable);
    $checktable = mysqli_num_rows($querychecktable);
    echo $checktable;
    if ($checktable > 0) {
        echo '
                <script>
                swal.fire({
                    icon:"warning",
                    title:"เกิดข้อผิดพลาด",
                    text:"คุณได้ทำรายการของ:เดือนนี้ หรือ ปีนี้ ไปเเล้ว",
                    type:"warning",
                    showConfirmButton: true,
                      
                });
                </script>
           ';
    } else {
        $years = $year['years'];
        $round = $_POST['round'];
        $date = $_POST['date'];
        $amount = $_POST['money'];
        $names = $name["memID"];
        $pname = $adname['pID'];

        $sqlinput =  "INSERT into saving (syear,sround,sDate,sAmount,memID,pID) value ($years,$round,$date,$amount,$names,$pname)";
        $queryinput = mysqli_query($conn, $sqlinput);
        $sqlmoney = "UPDATE member set memAmount = $amount where memID = '$id'";
        $querymoney = mysqli_query($conn, $sqlmoney);
        echo '
                <script>
                swal.fire({
                    icon:"success",
                    title:"ทำรายการเรียบร้อย",
                    text:"คุณได้เพิ่มรายการเรียบร้อยเเล้ว",
                    type:"success",
                    showConfirmButton: true,
                      
}).then(function() {
                window.location = "home.php";
            });
                </script>
           ';
    }
}
?>

</html>