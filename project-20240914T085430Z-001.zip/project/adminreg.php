<?php
include("conn.php");

if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);

if (isset($_POST['back'])) {
    header("location: home.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

<body>
<?php include("navbarmenu.php")?>
    <nav>
        <div class="container-fluid">
            <div class="row">
                <div class="col-3"></div>
                <div class="col-6">
                    <div class="card" style="margin-top: 5%;">
                        <div class="card-header bg-primary" style="text-align: center;">
                            <label for="" style="color:white;font-size:20px">ระบบสมัครเเอดมิน</label>
                        </div>
                        <form action="" method="post">
                            <div class="card-body">
                                <label for="">คำนำหน้าชื่อ</label>
                                <select name="title" id="" class="form-control form-group">
                                    <option value="นาย">นาย</option>
                                    <option value="นาง">นาง</option>
                                    <option value="นางสาว">นางสาว</option>
                                </select>
                                <label for="">อีเมล-email</label>
                                <input type="text" name="email" id="" class="form-control form-group" placeholder="กรุณากรอก:อีเมล" required="">
                                <label for="">ชื่อผู้ใช้งาน</label>
                                <input type="text" name="user" id="" class="form-control form-group" placeholder="Username" required="">
                                <label for="">รหัสผ่าน</label>
                                <input type="password" name="pass" id="" class="form-control form-group" placeholder="Password" required="">
                                <label for="">ชื่อ</label>
                                <input type="text" name="name" id="" class="form-control form-group" placeholder="โปรดป้อนชื่อ" required="">
                                <label for="">นามสกุล</label>
                                <input type="text" name="lastname" id="" class="form-control form-group" placeholder="โปรดป้อนนามสกุล" required="">
                                <label for="">เบอร์โทรศัพท์</label>
                                <input type="text" name="numphone" id="" class="form-control form-group" placeholder="xxx-xxx-xxxx" required="">
                                <label for="">เพศ</label>
                                <select name="gender" id="" class="form-control">
                                    <option value="ชาย">ผู้ชาย</option>
                                    <option value="หญิง">ผู้หญิง</option>
                                </select>
                            </div>
                            <div class="card-footer bg-primary" style="text-align: center;">
                                <button class="btn btn-success" name="reg" type="submit" style="font-size: 20px;">เรียบร้อย</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-3"></div>
            </div>
        </div>
    </nav>
    <?php
    if (isset($_POST["reg"])) {

        $pertitle = mysqli_real_escape_string($conn, $_POST['title']);
        $pername = mysqli_real_escape_string($conn, $_POST['name']);
        $perlastname = mysqli_real_escape_string($conn, $_POST['lastname']);
        $peruser = mysqli_real_escape_string($conn, $_POST['user']);
        $perpassword = md5(mysqli_real_escape_string($conn, $_POST['pass']));
        $pergender = mysqli_real_escape_string($conn, $_POST['gender']);
        $perphone = mysqli_real_escape_string($conn, $_POST['numphone']);

        $sqlcheck =  "SELECT pUsername from personal where pUsername = '$peruser'";
        $querycheck = mysqli_query($conn, $sqlcheck);
        $row =  mysqli_num_rows($querycheck);
        if ($row > 0) {
            echo '
            <script>
            swal.fire({
                icon:"error",
                title:"เกิดข้อผิดพลาด",
                text:"ชื่อผู้ใช้งานถูกใช้ไปเเล้ว",
                type:"error",
            });
        </script>
        ';
            } else {
                $sqladmin = "INSERT INTO personal (pTitle,pName,pLastname,pUsername,pPassword,pGender,pPhone) VALUES ('$pertitle', '$pername', '$perlastname', '$peruser', '$perpassword', '$pergender', '$perphone')";
                $queryadmin = mysqli_query($conn, $sqladmin);
                echo '
            <script>
                swal.fire({
                    icon:"success",
                    title:"สมัครสมาชิกเรียบร้อย",
                    text:"ยินดีต้อนรับ",
                    type:"success",
                    showConfirmButton: false,
                    timer:1000
                      
                }).then(function() {
                    window.location = "home.php";
                });
            </script>
            ';
                header("location: home.php");
            }
        }
    ?>
</body>

</html>