<?php
include("conn.php");
session_start();
$date = date("Y-m-d");
$pname = $_SESSION['username'];
$i = 1;
$id = isset($_GET['Lid']) ? $_GET['Lid'] : '';
if ($id != '') {
    $sqlinyear = "SELECT interestLoan from yeardata where Ystatus='N'";
    $queryinyear = mysqli_query($conn, $sqlinyear);
    $inyear  =  mysqli_fetch_array($queryinyear);

    $sqlcal = "SELECT * from loan where Lid = '$id'";
    $querycal = mysqli_query($conn, $sqlcal);
    $cal = mysqli_fetch_array($querycal);
    if (isset($_POST['pay'])) {
        $interest = $cal["Lremaining"]*($inyear["interestLoan"]/12)/100 ;
        if ($cal["Lremaining"] < $cal["Lsend"]) {
            $pay = $cal["Lremaining"];
            $total =  $cal["Lremaining"] - $pay;
        } else {
            $pay = $cal["Lsend"] - $interest;
            $total =  $cal["Lremaining"] - $pay;
        }
        if ($total == 0) {
            $sqlupdate1 = "UPDATE loan set Lstatus = 'S' where Lid = '$id'";
            $queryupdate1 = mysqli_query($conn, $sqlupdate1);
        }
        $sqlID = "SELECT memID from loan where Lid = '$id'";
        $queryID = mysqli_query($conn,$sqlID);
        $ID = mysqli_fetch_array($queryID);
        $sqlad = "SELECT pID from personal where pUsername='$pname'";
        $queryad = mysqli_query($conn, $sqlad);
        $adname = mysqli_fetch_array($queryad);
        $all = $pay + $interest;
        $update = "UPDATE loan set Lremaining = $total where Lid = '$id'";
        $queryupdate = mysqli_query($conn, $update);

        $savedata = "INSERT INTO loanData (LDamount,LDall,LDpay,LDinterest,Ldtotal,Lddate,pID,memID,Lid) values ('$cal[Lremaining]','$all','$pay','$interest','$total','$date',$adname[pID],$ID[memID],$id)";
        $querysavedata = mysqli_query($conn, $savedata);

        header("location: home.php");
    }
    $sql = "SELECT * from loan where memID =' " . $id . "'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
$sqlname = "SELECT * from loan inner join member on loan.memID = member.memID where Lstatus = 'N' && loan.Lid = '$id'";
$queryname = mysqli_query($conn, $sqlname);
$lname = mysqli_fetch_array($queryname);
$sqlcheck = "SELECT * from loan where Lid = '$id'";
$querycheck = mysqli_query($conn, $sqlcheck);
$check = mysqli_fetch_array($querycheck);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>ระบบชำระหนี้การกู้</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
        <img src="../assets/image/3.png" style="width: 50px;">
        <span class="" style="color: white; font-size:20px; margin:10px">ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</span>
        <ul class="navbar-nav ml-auto" style="margin-right: 20px; ">
            <li class="nav-item">
                <div>
                    <form action="" method="POST">
                        <a href="loan.php" class="btn btn-danger" name="back">กลับหน้าก่อนหน้า</a>
                    </form>
                </div>
            </li>
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card" style="margin-top:3%;">
                    <div class="card-header bg-primary" style="text-align: center;color:white;font-size:20px;">
                        <div>
                            <label for="">ระบบชำระหนี้</label>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div>
                                <table style="width: 100%;text-align:center" id="userinfo" class="table table-striped table-border">
                                    <tr style="background-color: lavender;">
                                        <th>ลำดับที่</th>
                                        <th>ชื่อ-นามสกุล</th>
                                        <th>เงินต้น</th>
                                        <th>เงินส่ง</th>
                                        <th>เงินคงเหลือ</th>
                                    </tr>
                                    <tr>
                                        <td><?php echo " " . $i;
                                            $i++; ?></td>
                                        <td><?php echo $lname['memName'] . '  ' . $lname['memLastname'] ?></td>
                                        <td><?php echo number_format($check['Lamount'],) ?></td>
                                        <td><?php echo number_format($check['Lsend'],) ?></td>
                                        <td><?php echo number_format($check['Lremaining'], 2) ?></td>
                                    </tr>
                                </table>
                            </div>
                    </div>
                    <div class="card-footer bg-primary" style="text-align: center;">
                        <button class="btn btn-success" type="submit" name="pay">กดชำระหนี้</button>
                    </div>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>
<?php
if($check['Lremaining'] == 0 ){
        echo '
        <script>
            swal.fire({
                icon:"success",
                title:"สำเร็จ",
                text:"จ่ายครบกำหนดเเล้ว",
                type:"success",
                  
            }).then(function() {
                window.location = "home.php";
            });
        </script>
        ';
    }
?>
</html>