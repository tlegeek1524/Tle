<?php
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION["username"])){
    header("Location: index.php");
}
if(isset($_GET["doLogout"]) && $_GET["doLogout"]==True){
    unset($_SESSION["username"]);
    header("Location: index.php");
}

include("connection.php");
$sqluser="select * from member where memNationalID='$_SESSION[username]'";
$query=mysqli_query($conn,$sqluser);
$result=mysqli_fetch_array($query);
$mID=$result["memID"];


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="bootstrap/js/jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>หน้าแรก</title>
    <style>
    body {
        background-color: #5d5858;
        font-family: 'Kanit', sans-serif;
        overflow-x: hidden;
    }

    a {
        color: #0060B6;
        text-decoration: none;
    }

    a:hover {
        color: #00A0C6;
        text-decoration: none;
        cursor: pointer;
    }
    footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: red;
        color: white;
        text-align: center;
      }
    </style>
</head>

<body>
<?php include("header.html");?>
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <div class="card border-0" style="margin:10px">
                <div class="card-header bg-info text-white" style="text-align: center;">
                    <label style="font-size: 20px; ">แก้ไขรหัสผ่าน</label>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>รหัสผ่านเก่า</label>
                            <input name="Oldpword" id="Oldpword" class="form-control" type="password"
                                placeholder="รหัสผ่านเก่า">
                        </div>
                        <div class="form-group" style="font-size: 18px;">
                            <label>รหัสผ่านใหม่</label>
                            <input name="NewpWord" id="NewpWord" class="form-control" type="password" value=""
                                placeholder="รหัสผ่านใหม่">
                        </div>
                        <div class="form-group" style="font-size: 18px;">
                            <label>ยืนยันรหัสผ่านใหม่</label>
                            <input name="ConfirmNewpWord" id="ConfirmNewpWord" class="form-control" type="password"
                                placeholder="ยืนยันรหัสผ่าน">
                        </div>
                        <div class="form-group" style="text-align:center">
                            <button class="btn btn btn-success" type="submit" name="passwordreset"
                                style="font-size: 20px;">เสร็จสิ้น</button>
                        </div>
                    </form>
</body>
<?php
if(isset($_POST["passwordreset"])){
    $passOld = md5($_POST["Oldpword"]);
    $password = md5($_POST["NewpWord"]);
    $Cpassword = md5($_POST["ConfirmNewpWord"]);
    if(isset($passOld) && !empty($passOld)){
        if($passOld!=$result["memPassword"]){
            echo "<script>";
            echo "
            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: 'รหัสผ่านไม่ถูกต้อง'
              });";
            echo "</script>";
        }else{
            if($password!=$Cpassword){
                echo "<script>";
                echo "
                Swal.fire({
                    icon: 'error',
                    title: 'เกิดข้อผิดพลาด',
                    text: 'รหัสผ่านไม่ตรงกัน'
                  });";
                echo "</script>";
            }else{
                $sql = "update member set
                memPassword='$password'
                where memID='$mID'";
                $query=mysqli_query($conn,$sql);
                echo '
                <script>
                    swal.fire({
                        icon:"success",
                        title:"สถานะ",
                        text:"บันทึกรหัสผ่านสำเร็จ",
                        type:"success",
                        showConfirmButton: false,
                        timer: 1000
                          
                    }).then(function() {
                        window.location = "profile.php";
                    });
                </script>
                ';
            }
        }
    }
}?>
<?php include("footer.html");?>
</html>