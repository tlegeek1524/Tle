<?php
include("conn.php");
if (isset($_SESSION)) {
    session_start();
}
$date = date("Y-m-d");

$status = $_POST['approve'];
$id = isset($_GET['id']) ? $_GET['id'] : '';
if ($id != '') {
    $sql = "SELECT * from loan where memID =' " . $id . "' && Lstatus='W'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
$sqlcheck = "select * from loan where Lid = '$id'";
$querycheck = mysqli_query($conn, $sqlcheck);
$check = mysqli_fetch_array($querycheck);

$sql1 = "SELECT * from member inner join loan on member.memID = $check[Lguarantor1]";
$query1 = mysqli_query($conn, $sql1);
$key = mysqli_fetch_array($query1);

$sql1 = "SELECT * from member inner join loan on member.memID = $check[Lguarantor2]";
$query1 = mysqli_query($conn, $sql1);
$key1 = mysqli_fetch_array($query1);

$sql1 = "SELECT * from member inner join loan on member.memID = $check[Lguarantor3]";
$query1 = mysqli_query($conn, $sql1);
$key2 = mysqli_fetch_array($query1);


if (isset($_POST['success'])) {
    $sql = "UPDATE loan set Lstatus='$status',Lremaining=Lamount,Lapprovedate='$date' where Lid = '$id'";
    $query = mysqli_query($conn, $sql);
    header("location: loan.php");
}
if (isset($_POST['back'])) {
    header("location: loan.php");
}
$sqlname = "SELECT * from loan inner join member on loan.memID=member.memID where loan.Lid ='$id'";
$queryname = mysqli_query($conn, $sqlname);
$data = mysqli_fetch_array($queryname);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }

    table,
    th {
        border: 0.5px solid black;

    }

    td {
        border: 1px solid darkgray;
    }

    tr:hover {
        background-color: lavender;
    }
</style>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card">
                    <div class="card-header bg-primary">
                        <div>
                            <label for="">ตรวจสอบสถานะ/การกู้เงิน</label>
                        </div>
                    </div>
                    <form action="" method="post">
                        <div class="card-body">
                            <label for="">ชื่อ</label>
                            <input readonly type="text" name="name" id="" value="<?php echo $data['memName'] . '  ' . $data['memLastname'] ?>" class="form-control form-group">
                            <label for="">เงินต้น</label>
                            <input readonly type="text" name="money1" id="" value="<?php echo $check["Lcapital"] ?>" class="form-control form-group">
                            <label for="">เงินกู้</label>
                            <input readonly type="text" name="money2" id="" value="<?php echo $check["Lamount"] ?>" class="form-control form-group">
                            <label for="">เงินส่ง</label>
                            <input readonly type="text" name="money3" id="" value="<?php echo $check["Lsend"] ?>" class="form-control form-group">
                            <label for="">ผู้ค้ำประกัน</label>
                            <input readonly type="text" name="" id="" class="form-control form-group" value="<?php echo $key['memName'] . ' ' . $key['memLastname'] ?>">
                            <input readonly type="text" name="" id="" class="form-control form-group" value="<?php echo $key1['memName'] . ' ' . $key1['memLastname'] ?>">
                            <input readonly type="text" name="" id="" class="form-control form-group" value="<?php echo $key2['memName'] . ' ' . $key2['memLastname'] ?>">
                            <label for="">ตรวจสอบสถานะ</label>
                            <select name="approve" id="" class="form-control form-group">
                                <option value="N">ผ่าน</option>
                                <option value="C">ไม่ผ่าน</option>
                            </select>
                        </div>
                </div>
                <div class="card-footer bg-primary" style="text-align: center;">
                    <button class="btn btn-success" type="submit" name="success">เรียบร้อย</button>
                    <button class="btn btn-danger" type="submit" name="back">กลับหน้าหลัก</button>
                </div>
                </form>
            </div>
        </div>
        <div class="col-3"></div>
    </div>
    </div>
</body>

</html>