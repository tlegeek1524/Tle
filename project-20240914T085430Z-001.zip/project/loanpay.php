<?php
include("conn.php");
session_start();
$sqltable = "SELECT * from member";
$querytable = mysqli_query($conn,$sqltable);
$sqlmoney = "SELECT * from loan where Lstatus ='N'";
$querymoney = mysqli_query($conn, $sqlmoney);
$money = mysqli_fetch_array($querymoney);
$sqlname = "SELECT * from loan inner join member on loan.memID = member.memID where Lstatus = 'N'";
$queryname = mysqli_query($conn, $sqlname);
$adname = $_SESSION['username'];
$date =  $_POST['date'];
$name = $_POST['name'];
if (isset($_POST["success"])) {
    header("location:home.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>ระบบออมทรัพย์</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
        <img src="../assets/image/3.png" style="width: 50px;">
        <span class="" style="color: white; font-size:20px; margin:10px">ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</span>
        <ul class="navbar-nav ml-auto" style="margin-right: 20px; ">
            <li class="nav-item">
                <div>
                    <form action="" method="POST">
                        <a href="home.php" class="btn btn-danger" name="back">กลับสู่หน้าหลัก</a>
                    </form>
                </div>
            </li>
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card" style="margin-top: 3%;">
                    <div class="card-header bg-primary" style="text-align: center;color:white;font-size:20px;">
                        <label for="">หน้า-ชำระหนี้</label>
                    </div>
                    <form action="" method="POST">
                        <div>
                            <table style="width: 100%;text-align:center" id="userinfo" class="table table-striped table-border">
                                <tr style="background-color: lavender;">
                                   <th>ลำดับที่</th>
                                   <th>ชื่อ-นามสกุล</th>
                                   <th>เงินต้น</th>
                                   <th>เงินส่ง</th>
                                   <th>เงินคงเหลือ</th>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>2</td>
                                    <td>3</td>
                                    <td>4</td>
                                    <td>5</td>
                                </tr>
                            </table>
                        </div>
                        <div class="card-footer bg-primary" style="text-align: center;">
                            <div>
                                <button class="btn btn-success" type="submit" name="success">เรียบร้อย</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>

</html>