<?php
include("conn.php");
include("../datethai.php");
session_start();
$date = date("Y-m-d");
$pname = $_SESSION['username'];
$id = isset($_GET['Lid']) ? $_GET['Lid'] : '';
if ($id != '') {
    $sqltable="select * from loanData inner join loan on loanData.Lid=loan.Lid where loanData.Lid=$id ORDER BY loanData.Lid ASC";
    $querytable=mysqli_query($conn,$sqltable);
    $debt=mysqli_fetch_array($querytable);
    echo $sqltable;

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>ระบบชำระหนี้การกู้</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>
<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
        <img src="../assets/image/3.png" style="width: 50px;">
        <span class="" style="color: white; font-size:20px; margin:10px">ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</span>
        <ul class="navbar-nav ml-auto" style="margin-right: 20px; ">
            <li class="nav-item">
                <div>
                    <form action="" method="POST">
                        <a href="loan.php" class="btn btn-danger" name="back">กลับหน้าก่อนหน้า</a>
                    </form>
                </div>
            </li>
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
            <div class="card" style="margin:10px;">
                <div class="card-header bg-primary text-white" style="text-align: center;">
                    <div style="font-size:30px; font-weight:bold;">ประวัตการชำระหนี้</div>
                </div>
                <div class="card-body">
                <div style="font-size:40px; text-align: right; text-align:center;" >ยอดเงินกู้คงเหลือ</br>
                        <span><?php echo number_format($debt["Lremaining"], 2);?>   บาท</span>
                </div>
                    <table style="width: 100%; text-align:center; font-size:16px; margin-top:10px;" class="table table-sm" id="debtinfo">
                        <thead class="bg-primary">
                            <tr style="margin-top: 20px;color:white;">
                                <th>ลำดับ</th>
                                <th>วันที่</th>
                                <th>เงินกู้</th>
                                <th>เงินต้น</th>
                                <th>ดอกเบี้ย</th>
                                <th>ทั้งหมด</th>
                                <th>คงเหลือ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1;?>
                            <?php foreach($querytable as $data) {?>
                            <tr>
                                <th><?php echo $i; $i++;?></th>
                                <th><?php echo DateThai($data['Lddate']);?></th>
                                <th><?php echo number_format($data['LDamount'], 2);?></th>
                                <th><?php echo number_format($data['LDpay'], 2);?></th>
                                <th><?php echo number_format($data['LDinterest'], 2);?></th>
                                <th><?php echo number_format($data['LDall'], 2);?></th>
                                <th><?php echo number_format($data['Ldtotal'], 2);?></th>
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
            </div>
        </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>
</html>