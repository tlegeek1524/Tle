<?php
include("conn.php");
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);
if (isset($_POST['back'])) {
    header("location: home.php");
}
if (isset($_POST['wihtdraw'])) {
    header("location: wihtdraw.php");
}
$pname = $_SESSION['username'];
$sql = "SELECT * from member";
$query = mysqli_query($conn, $sql);
$sqlshow = "SELECT rounds from rounddata where rStatus = 'N'";
$queryshow = mysqli_query($conn, $sqlshow);
$show = mysqli_fetch_array($queryshow);
$sqlad = "SELECT pID from personal where pUsername='$pname'";
$queryad = mysqli_query($conn, $sqlad);
$adname = mysqli_fetch_array($queryad);
$sqlyear = "SELECT * from yeardata where Ystatus ='N'";
$queryyear = mysqli_query($conn, $sqlyear);
$year = mysqli_fetch_array($queryyear);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title><?php echo $_SESSION["titlebar"]?></title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

<body>
<?php include("navbarmenu.php")?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div class="card" style="margin-top: 50px;">
                    <div class="card-header bg-primary" style="text-align:center">
                        <label style="font-size:20px; color:white;">ระบบออมทรัพย์</label>
                    </div>
                    <form action="" method="POST">
                        <div class="card-body">
                            <label for="">รอบ/เดือน</label>
                            <select name="round" id="" class="form-control form-group">
                                <?php foreach ($queryshow as $data) { ?>
                                    <option value="<?php echo $data['rounds']?>">
                                    <?php 
                                    if($data['rounds']== 0){
                                     echo "ยอดยกมา" ;
                                    }else{echo $data['rounds'];}?>
                                    </option>
                                <?php } ?>
                            </select>
                            <label for="">ปี</label>
                            <input readonly type="text" name="year" id="" value="<?php echo $year['years'] ?>" class="form-control form-group">
                            <label class="">วันที่</label>
                            <input  value="<?php echo date("Y-m-d") ?>" type="date" type="text" name="date" id="" class="form-control form-group">
                        </div>
                        <div class="card-footer bg-primary" style="text-align:center;">
                            <button class="btn btn-success" type="submit" name='next'>บันทึกข้อมูล</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
    <?php
    if (isset($_POST['next'])) {
            $rounds = $_POST['round'];
            $years = $year['years'];
            $date = $_POST['date'];
            $ad  = $adname['pID'];
            $sqlstatus ="UPDATE rounddata Set rStatus='C' where rYear=$year[years] && rounds=$_POST[round]";
            $querystatus = mysqli_query($conn,$sqlstatus);
            while ($row = mysqli_fetch_array($query)) {
                $name = $row['memID'];
                $amount = $row['memAmount'];
                $sqlsaving = "INSERT INTO saving (syear,sround,sDate,sAmount,memID,pID) values ($years,$rounds,'$date',$amount,$name,$ad)";
                $querysaving = mysqli_query($conn, $sqlsaving);
            }
            echo '
        <script>
            swal.fire({
                icon:"success",
                title:"เรียบร้อย",
                text:"ทำรายการสำเร็จ",
                type:"success",
                showConfirmButton: false,
                timer:1000
                  
            }).then(function() {
                window.location = "home.php";
            });
        </script>
        ';
        }
    ?>
</body>

</html>