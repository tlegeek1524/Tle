<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="bootstrap/js/jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</title>
    <style>
    body {
        background-color: ;
        font-family: 'Kanit', sans-serif;
    }
    </style>
</head>

<body>
    <br>
    <br>
    <div class="row" style="text-align:center">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <div class="col-md-12">
                <h3>ผู้จัดทำ</h3>
                <img src="https://159.192.102.92/files/15810_19110119191021.jpg" width="200px" height=200px class="rounded-circle">
                <p>นายสัจจา มโนมัยนุกุล</p>
                <p>อาจารย์ที่ปรึกษา</p>
            </div>
            <div class="row" style="text-align:center">
                <div class="col-md-6">
                    <img src="https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.6435-9/118692324_746474585920946_1338953776739336289_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeGyLoZ2WaxOs5OfBVabzbGiWIlNjHciP4BYiU2MdyI_gBDvD--N4t3LGfYbf3_NpnhmI9DJSh_qc04-PsrDXuX0&_nc_ohc=A4VApwwUlwYAX-AK4Kf&_nc_ht=scontent.fbkk10-1.fna&oh=19c35a93ce8de543611cc44cd015daad&oe=61D4FA8A" width="200px" height=200px class="rounded-circle">
                    <p>นายธีรภัทร ประคองพันธ์</p>
                    <p>นักศึกษา</p>
                </div>
                <div class="col-md-6">
                    <img src="https://scontent.fbkk10-1.fna.fbcdn.net/v/t39.30808-6/250203114_1292369947932516_1412655836580105313_n.jpg?_nc_cat=103&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeEyAVUQ0juaXevWtw9XN0zDVBUp-mcEIMpUFSn6ZwQgyhiNsLwVRA9ifi_vbsZ9UP0k-UAnKOWFy_eaZlyalp8R&_nc_ohc=yw2i-fubx8oAX9y0QY2&_nc_ht=scontent.fbkk10-1.fna&oh=c4d6e42f401f832dd41212952e3ac325&oe=61B49C06" width="200px" height=200px class="rounded-circle">
                    <p>นายศุภกิตติ์ ราญพล</p>
                    <span>นักศึกษา</span>
                </div>
            </div>
            <div class="row" style="text-align:center">
                <div class="col-md-6">
                    <img src="https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.6435-9/174534919_1811185982393818_177877656685472779_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeG_uz6r62Ao8jGgGBC6dvAaWaYRhLm7K9RZphGEubsr1Ed9XGUz8-Aw3xOYl7foAVmOZJYW-ycX0XqUPmMYXW89&_nc_ohc=Mgh9VN5XbMYAX_y4ntK&tn=Gactma31cLfQQSOg&_nc_ht=scontent.fbkk10-1.fna&oh=e73b343f4f4ed03a8ae03a0dc62c4da2&oe=61D5999F" width="200px" height=200px class="rounded-circle">
                    <p>นายตันติกร พุ่มเหรียญ</p>
                    <p>นักศึกษา</p>
                </div>
                <div class="col-md-6">
                    <img src="https://scontent.fbkk10-1.fna.fbcdn.net/v/t1.18169-9/14102471_164698413970063_7387070890287404249_n.jpg?_nc_cat=102&ccb=1-5&_nc_sid=174925&_nc_eui2=AeGkW33XsJXiBsIyH6pXkJCBdoFIU5PI-o52gUhTk8j6jowUaJdeCGEEdRHtlKzmOxn-iQgbGyIDzwuv7WRa91Vc&_nc_ohc=Q20-CRZPBncAX-8dAbg&_nc_ht=scontent.fbkk10-1.fna&oh=8f8c2df4e0a58222fb6625379b2ea41d&oe=61D57202 " width="200px" class="rounded-circle" height=200px>
                    <p>นางสาวประภัสสร บุญประเสริฐ</p>
                    <p>นักศึกษา</p>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
        </div>
    </div>
    </div>
    </div>

</body>

</html>