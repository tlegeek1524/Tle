<?php
include("conn.php");

if (isset($_POST['back'])) {
    header("location: home.php");
}
if (isset($_POST['success'])) {

    header("location:home.php");
}
$id = isset($_GET['id']) ? $_GET['id'] : '';
if ($id != '') {

    $sql = "SELECT * from personal where pID =' " . $id . "'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

<body>
    <?php include("navbarmenu.php") ?>
    <div class="container-fluid">
        <div class="row" style="margin-top: 1%;">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card">
                    <div class="card-header bg-primary" style="text-align: center;">
                        <label for="" style="font-size:20px; color:white;">ข้อมูลส่วนบุคคล</label>
                    </div>
                    <form action="" method="post">
                        <div class="card-body">
                            <table style="width: 100%;text-align:center;" id="userinfo" class="table table-striped table-border">
                                <tr>
                                    <th>เพศ</th>
                                    <th>ชื่อ-นามสกุล</th>
                                    <th>ชื่อผู้ใช้งาน</th>
                                    <th>เบอร์โทรศัพท์</th>
                                </tr>
                                <tr>
                                    <td><?php echo $row['pGender']?></td>
                                    <td><?php echo $row['pName'].'  '.$row['pLastname']?></td>
                                    <td><?php echo $row['pUsername']?></td>
                                    <td><?php echo $row['pPhone']?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="card-footer bg-primary" style="text-align: center;">
                            <button class="btn btn-success" style="font-size:20px; color:white" name="success">บันทึกข้อมูล</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>

</html>