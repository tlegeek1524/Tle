<?
include("conn.php");
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);

$sqlyear = "select years from yeardata where Ystatus = 'N'";
$queryyear = mysqli_query($conn, $sqlyear);
$year = mysqli_fetch_array($queryyear);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title><?php echo $_SESSION["titlebar"] ?></title>
</head>
<style>
    body {
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
</style>

<body>
    <?php
    include("navbarmenu.html")?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="card" style="margin-top: 5%;">
                    <div class="card-header bg-primary" style="text-align:center">
                        <label style="font-size:20px; color:white;">เพิ่มรอบ/ปี</label>
                    </div>
                    <form action="" method="POST">
                        <div class="card-body">
                            <div>
                                <label for="">ปี</label>
                                <input readonly type="text" name="year" id="" class="form-control form-group" value="<?php echo $year['years'] ?>">
                            </div>
                            <div>
                                <label for="">รอบ/เดือน</label>
                                <input readonly type="text" name="" id="" value="<?php echo '1-12' ?>" class="form-control">
                            </div>
                        </div>
                        <div class="card-footer bg-primary" style="text-align: center;">
                            <button class="btn btn-success" name="success" type="submit">ทำรายการ</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</body>
<?php
$sqlcheck = "SELECT * from rounddata where rYear = '$year[years]'";
$querycheck =  mysqli_query($conn, $sqlcheck);
$check = mysqli_num_rows($querycheck);
if (isset($_POST['success'])) {
    if ($check > 0) {
        echo ' 
         <script>
         alert("คุณได้ทำรายการของปีนี้ไปเเล้ว");
         </script>
         ';
    } else {
        for ($i = 1; $i <= 12; $i++) {
            $sqlround = "INSERT into rounddata (rYear,rounds) value ($year[years],$i)";
            $queryround = mysqli_query($conn, $sqlround);
        }
    }
}
?>

</html>