<?php
    include("conn.php");
    if(!isset($_SESSION)){
        session_start();
    }
    $_SESSION['titlebar']="ระบบออมทรัพย์วิทยาลัยเทคนิคกำแพงเพชร";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">  
    <title><?php echo $_SESSION["titlebar"]?></title>
</head>
<style>
        body{
        background-color: lightblue;
        font-family: 'Kanit', sans-serif;
    }
    a {
        color: #0060B6;
        text-decoration: none;
    }

    a:hover {
        color: #00A0C6;
        text-decoration: none;
        cursor: pointer;
    }
</style>
<body>
<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
<div class="container-fluid">
    <div class="navbar-brand navbar-expand-lg">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <img src="../assets/image/3.png" style="width: 50px;">
        <span class="" style="color: white; font-size:20px; margin:10px">ระบบออมทรัพย์ครูวิทยาลัยเทคนิคกำแพงเพชร</span>
        </div>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ml-auto" style="margin-right:20px; font-size: 20px;">
        <li>
            <a href="../index.php">
            <!-- <img src="../image/user-icon.png" style="width:30px;"> -->
            <button style="color:black" class="btn btn-light">ระบบสมาชิก</button>
        </a>
        </li>
        </ul>
</div>
</div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2 col-sm-3 col-md-3 col-lg-3"></div>
            <div class="col-8 col-sm-6 col-md-6 col-lg-6">
                <div class="card" style="margin-top: 10%; " >
                    <div class="card-header bg-primary" style="text-align: center;font-size:20px;">
                        <lable style="color:white;">ลงชื่อเข้าใช้งานระบบผู้ดูเเล</label>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">ชื่อผู้ใช้งาน</label>
                            <input type="text" class="form-control" placeholder="Username" name="uName">
                        </div>
                        <div class="form-group">
                            <label for="">รหัสผ่าน</label>
                            <input type="password" name="pWord" id="pWord" class="form-control" placeholder="Password">
                        </div>
                    </div>
                    <div class="card-footer bg-primary">
                        <div style="text-align:center;">
                            <button class="btn btn-success" type=submit name="Login" style="font-size: 20px;">เข้าสู่ระบบ</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class=" col-2 col-sm-3 col-md-3 col-lg-3"></div>
        </div>  
    </div>
    <?php
        if(isset($_POST["Login"])){
            $un=$_POST["uName"];
            $pw=md5($_POST["pWord"]);
            $sql="select * from personal where pUsername='$un' and pPassword='$pw'";
            $query=mysqli_query($conn,$sql);
            $row=mysqli_num_rows($query);
            if($row>0){
                $_SESSION["username"]=$un;
                $_SESSION["password"]=$pw;
                echo '
                <script>
                    swal.fire({
                        icon:"success",
                        title:"เข้าระบบสำเร็จ",
                        text:"ยินดีต้อนรับ",
                        type:"success",
                        showConfirmButton: false,
                        timer:1000
                          
                    }).then(function() {
                        window.location = "home.php";
                    });
                </script>
                ';
            }else
           echo'
                <script>
                swal.fire({
                    icon:"error",
                    title:"เข้าระบบไม่สำเร็จ",
                    text:"ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง",
                    type:"error",
                })
                </script>
           ';
        }
    ?>
</body>
</html>