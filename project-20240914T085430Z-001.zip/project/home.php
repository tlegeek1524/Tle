<?php
include("conn.php");
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
}
if (!isset($_SESSION['password'])) {
    header("location: index.php");
}
if (isset($_GET["doLogout"]) && $_GET["doLogout"] == True) {
    unset($_SESSION["username"]);
    header("Location: index.php");
}
$sqluser = "select * from personal where pUsername = '$_SESSION[username]'";
$queryuser = mysqli_query($conn, $sqluser);
$result = mysqli_fetch_array($queryuser);

$sqltable = "SELECT * FROM member";
$querytable = mysqli_query($conn, $sqltable);

$i = 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <title>ระบบออมทรัพย์วิทยาลัยเทคนิคกำแพงเพชร</title>
</head>
<style>
body {
    background-color: lightblue;
    font-family: 'Kanit', sans-serif;
}
</style>
<?php include("navbarmenu.php")?> 
<body>
    <div class="container-fluid">
    <div class="row" style="margin-top: 2%;">
        <div class="col-sm-4 col-md-3 col-lg-2"></div>
        <div class="col-sm-4 col-md-6 col-lg-8">
            <div class="card">
                <div class="card-header bg-primary">
                    <div style="text-align: center;color:white;font-size:20px;">
                        <label for="">ข้อมูลสมาชิก</label>
                    </div>
                </div>
                <div class="card-body">
                <table style="width: 100%;text-align:center;" id="userinfo" class="table table-striped table-border">
                <thead>
                    <tr style="background-color: lavender;">
                        <th>ลำดับที่</th>
                        <th>ชื่อ-นามสกุล</th>
                        <th>เบอร์โทรศัพท์</th>
                        <th style="text-align: center;">เพศ</th>
                        <th>เเก้ไข</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($querytable as $data) { ?>
                    <tr>
                        <td><?php echo " " . $i;
                                $i++; ?></td>
                        <td><?php echo $data['memTitle'] . ' ' . $data['memName'] . '  ' . $data['memLastname'] ?></td>
                        <td><?php echo $data['memPhone']?></td>
                        <td style="text-align: center;"><?php echo $data['memGender'] ?></td>
                        <td>
                            <form action="" method="post">
                                <a name="editer" href="editdata.php?id=<?php echo $data['memID'] ?>"
                                    class="btn btn-outline-danger">เเก้ไข</a>
                                <a name="savecheck" href="savingcheck.php?id=<?php echo $data['memID'] ?>"
                                    class="btn btn-warning">ตรวจสอบการออม</a>
                            </form>
                        </td>
                        <?php } ?>
                    </tr>

                    </tbody>
                </table>
                </div>
                <div class="card-footer bg-primary"></div>
            </div>
        </div>
        <div class="col-sm-4 col-md-3 col-lg-2"></div>
    </div>
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <script>
    $(document).ready(function() {
    $('#userinfo').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/th.json',
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
            'print'
        ],
        }
    } );
} );

</script>
</div>
</body>
<?php
 if($_SESSION["username"]){
    echo '
    <script>
     alert(ยินดีต้อนรับ);
    </script>
    ';
 }
?>
</html>